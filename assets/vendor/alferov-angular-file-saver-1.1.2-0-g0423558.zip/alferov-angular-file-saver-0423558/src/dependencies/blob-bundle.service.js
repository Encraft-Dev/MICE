'use strict';

require('Blob.js');

module.exports = function Blob($window) {
  return $window.Blob;
};
